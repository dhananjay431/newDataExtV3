const jsonPath = "content-understanding.json";
const svgContainer = document.getElementById("svg-canvas");
const list = document.getElementById("field-list");
const status = document.getElementById("status");
let draw = null;
let regions = [];
let selectedRegionId = null;
let hoveredRegionId = null;

function initCanvas() {
  draw = SVG().addTo(svgContainer).size("612px", "792px");
}

function parseSource(source) {
  if (typeof source !== "string") {
    return null;
  }
  const match = source.match(/^D\(([^)]+)\)$/);
  if (!match) {
    return null;
  }
  const numbers = match[1]
    .split(",")
    .map((value) => parseFloat(value.trim()))
    .filter((value) => !Number.isNaN(value));
  if (numbers.length < 3) {
    return null;
  }
  const pageNumber = numbers[0];
  const coordinates = numbers.slice(1);
  if (coordinates.length % 2 !== 0) {
    return null;
  }
  const points = [];
  for (let i = 0; i < coordinates.length; i += 2) {
    points.push({ x: coordinates[i], y: coordinates[i + 1] });
  }
  return { pageNumber, points };
}

function getPreviewText(node) {
  if (node == null) return "";
  if (typeof node === "string") return node;
  if (typeof node === "number") return String(node);
  if (typeof node === "boolean") return String(node);
  if (node.valueString) return node.valueString;
  if (node.valueNumber !== undefined) return String(node.valueNumber);
  if (node.type) return node.type;
  return JSON.stringify(node).slice(0, 50);
}

function walkNode(node, path = []) {
  if (Array.isArray(node)) {
    node.forEach((item, index) => walkNode(item, path.concat(`[${index}]`)));
    return;
  }
  if (node && typeof node === "object") {
    if (node.source) {
      const parsed = parseSource(node.source);
      if (parsed) {
        regions.push({
          id: `region-${regions.length + 1}`,
          path: path.length ? path.join(".") : "root",
          preview: getPreviewText(node),
          source: node.source,
          parsed,
          svgElement: null,
          listElement: null,
        });
      }
    }
    Object.entries(node).forEach(([key, value]) => {
      if (key === "source") return;
      walkNode(value, path.concat(key));
    });
  }
}

function updateRegionStates() {
  regions.forEach((region) => {
    const selected = selectedRegionId === region.id;
    const hovered = hoveredRegionId === region.id;
    if (region.svgElement) {
      if (selected) {
        region.svgElement.addClass("active");
      } else {
        region.svgElement.removeClass("active");
      }
      if (hovered && !selected) {
        region.svgElement.addClass("hovered");
      } else {
        region.svgElement.removeClass("hovered");
      }
    }
    region.listElement.classList.toggle("active", selected);
    region.listElement.classList.toggle("hovered", hovered && !selected);
  });
}

function setSelectedRegion(regionId) {
  selectedRegionId = selectedRegionId === regionId ? null : regionId;
  updateRegionStates();
  const region = regions.find((item) => item.id === selectedRegionId);
  status.textContent = region
    ? `Selected region: ${region.path} — ${region.preview}`
    : `Click a region list item or an SVG highlight to see details.`;
}

function setHoveredRegion(regionId) {
  hoveredRegionId = regionId;
  updateRegionStates();
}

function buildSVG() {
  const allPoints = regions.flatMap((region) => region.parsed.points);
  if (!allPoints.length) {
    draw?.clear();
    return;
  }

  if (!draw) {
    initCanvas();
  }

  const minX = Math.min(...allPoints.map((point) => point.x));
  const maxX = Math.max(...allPoints.map((point) => point.x));
  const minY = Math.min(...allPoints.map((point) => point.y));
  const maxY = Math.max(...allPoints.map((point) => point.y));
  const padding = Math.max(maxX - minX, maxY - minY) * 0.05 + 0.5;
  const width = maxX - minX + padding * 2;
  const height = maxY - minY + padding * 2;

  draw.clear();
  draw.viewbox(minX - padding, minY - padding, width, height);
  draw
    .rect(width, height)
    .move(minX - padding, minY - padding)
    .fill("#f8fafb");

  regions.forEach((region) => {
    const points = region.parsed.points.flatMap((point) => [point.x, point.y]);
    const polygon = draw
      .polygon(points)
      .fill("rgba(59, 130, 246, 0.18)")
      .stroke({ color: "rgba(37, 99, 235, 0.9)", width: 0.08 })
      .addClass("region");

    polygon.on("mouseenter", () => setHoveredRegion(region.id));
    polygon.on("mouseleave", () => setHoveredRegion(null));
    polygon.on("click", () => setSelectedRegion(region.id));
    region.svgElement = polygon;

    if (region.parsed.points.length > 0) {
      const first = region.parsed.points[0];
      draw
        .text(region.id)
        .font({ size: 10, family: "system-ui, sans-serif" })
        .move(first.x + 0.05, first.y - 0.1)
        .addClass("region-label");
    }
  });
}

function renderFieldList() {
  if (!regions.length) {
    list.innerHTML =
      "<p>No <code>source</code> entries were found in the JSON.</p>";
    return;
  }
  list.innerHTML = "";

  regions.forEach((region) => {
    const item = document.createElement("button");
    item.className = "field-item";
    item.type = "button";
    item.innerHTML = `
      <span class="label">${region.path}</span>
      <span>${region.preview}</span>
      <span class="source">${region.source}</span>
    `;
    item.addEventListener("click", () => setSelectedRegion(region.id));
    item.addEventListener("mouseenter", () => setHoveredRegion(region.id));
    item.addEventListener("mouseleave", () => setHoveredRegion(null));
    region.listElement = item;
    list.appendChild(item);
  });
}

function showStatus(message) {
  status.textContent = message;
}

function loadJson() {
  fetch(jsonPath)
    .then((response) => {
      if (!response.ok) {
        throw new Error(
          `Failed to fetch ${jsonPath}: ${response.status} ${response.statusText}`,
        );
      }
      return response.json();
    })
    .then((json) => {
      const contents = json?.result?.contents;
      if (!Array.isArray(contents) || !contents.length) {
        showStatus("No JSON contents were found in the document.");
        return;
      }
      walkNode(contents[0]);
      buildSVG();
      renderFieldList();
      showStatus(
        `Loaded ${regions.length} source region${regions.length === 1 ? "" : "s"}. Click any item to highlight it.`,
      );
    })
    .catch((error) => {
      showStatus(`Error loading JSON: ${error.message}`);
      list.innerHTML = "";
    });
}

loadJson();
